import tkinter as tk
from tkinter import messagebox, filedialog, simpledialog
import hashlib
import json
import os
import time
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
import base64

# Répertoire de stockage
SAVE_PATH = r"C:\Users\sirin\Desktop\cybersecurity\S2\python\projet"
ACCOUNTS_FILE = os.path.join(SAVE_PATH, "accounts.json")
VAULT_FILE = os.path.join(SAVE_PATH, "vaults.json")

def ensure_data_files():
    os.makedirs(SAVE_PATH, exist_ok=True)
    if not os.path.exists(ACCOUNTS_FILE): open(ACCOUNTS_FILE, "w").close()
    if not os.path.exists(VAULT_FILE):
        with open(VAULT_FILE, "w") as f: json.dump({}, f)

# Fonctions utilitaires
# Hache le mot de passe avec le sel:
def hash_password(password, salt):
    return hashlib.sha256((password + salt).encode()).hexdigest()

'''def pad(data):
    data = data.encode()  
    padding_length = 16 - (len(data) % 16)
    return data + bytes([padding_length]) * padding_length'''

# Applique le padding
def padfile(data):
    if isinstance(data, str):
        data = data.encode()
    padding_length = 16 - (len(data) % 16)
    return data + bytes([padding_length]) * padding_length

# Retire le padding après déchiffrement
def unpad(data):
    padding_length = data[-1]
    return data[:-padding_length]

# Chiffrement AES CBC avec IV aléatoire
def encrypt_AES(data, key):
    cipher = AES.new(key, AES.MODE_CBC)
    ct_bytes = cipher.encrypt(padfile(data))  
    iv = base64.b64encode(cipher.iv).decode('utf-8')
    ct = base64.b64encode(ct_bytes).decode('utf-8')
    return json.dumps({'iv': iv, 'ciphertext': ct})

# Déchiffre en vérifiant la structure et le padding
def decrypt_AES(enc_data, key):
    try:
        b64 = json.loads(enc_data)
        iv = base64.b64decode(b64['iv'])
        ct = base64.b64decode(b64['ciphertext'])
        cipher = AES.new(key, AES.MODE_CBC, iv)
        pt = unpad(cipher.decrypt(ct))
        return pt.decode('utf-8')  
    except:
        return None

# Dérive une clé AES 256 bits
def derive_key(password):
    return hashlib.sha256(password.encode()).digest()

class PasswordManagerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Gestionnaire de mots de passe sécurisé")
        self.current_user = None
        self.session_start_time = None
        self.login_attempts = 0
        self.max_attempts = 3
        self.session_timeout = 60
        self.last_failed_time = None
        self.LOCK_DURATION = 30  
        self.encryption_key = get_random_bytes(16)

        self.build_main_menu()

    def clear_window(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    def build_main_menu(self):
        self.clear_window()
        tk.Label(self.root, text="Bienvenue dans le gestionnaire de mots de passe", font=("Arial", 16),fg="red").pack(pady=20)
        if self.current_user:
            tk.Label(self.root, text=f"Connecté en tant que : {self.current_user}", fg="green", font=("Arial", 12)).pack(pady=5)
        tk.Button(self.root, text="Connexion", width=30, command=self.login_window).pack(pady=10)
        tk.Button(self.root, text="Créer un compte", width=30, command=self.register_window).pack(pady=10)
        tk.Button(self.root, text="À propos", width=30, command=self.about_window).pack(pady=10)
        tk.Button(self.root, text="Quitter", width=30, command=self.root.quit).pack(pady=20)

    def login_window(self):
     self.clear_window()
     tk.Label(self.root, text="Connexion", font=("Arial", 16), fg="red").pack(pady=10)

     tk.Label(self.root, text="Nom d'utilisateur").pack()
     self.username_entry = tk.Entry(self.root)
     self.username_entry.pack()

     tk.Label(self.root, text="Mot de passe").pack()
     self.password_entry = tk.Entry(self.root, show='*')
     self.password_entry.pack()
    
     show_pwd = tk.BooleanVar()
     tk.Checkbutton(self.root, text="Afficher", variable=show_pwd,
                   command=lambda: self.password_entry.config(show="" if show_pwd.get() else "*")).pack()

     self.lockout_label = tk.Label(self.root, fg="orange")
     self.lockout_label.pack()

     self.login_button = tk.Button(self.root, text="Se connecter")
     self.login_button.config(command=lambda: attempt_login())
     self.login_button.pack(pady=10)

     tk.Button(self.root, text="Retour", command=self.build_main_menu).pack(pady=5)

     def start_countdown():
        def update_countdown():
            remaining = int(self.LOCK_DURATION - (time.time() - self.last_failed_time))
            if remaining > 0:
                self.lockout_label.config(text=f"Trop de tentatives. Réessayez dans {remaining} secondes.")
                self.login_button.config(state=tk.DISABLED)
                self.root.after(1000, update_countdown)
            else:
                self.lockout_label.config(text="")
                self.login_button.config(state=tk.NORMAL)
                self.login_attempts = 0
                self.last_failed_time = None

        update_countdown()

     def attempt_login():
        now = time.time()

        if self.login_attempts >= self.max_attempts:
            if self.last_failed_time and now - self.last_failed_time < self.LOCK_DURATION:
                start_countdown()
                return
            else:
                self.login_attempts = 0
                self.last_failed_time = None
                self.lockout_label.config(text="")
                self.login_button.config(state=tk.NORMAL)

        username = self.username_entry.get()
        password = self.password_entry.get()

        if self.authenticate_user(username, password):
            self.current_user = username
            self.session_password = password
            self.session_start_time = time.time()
            self.login_attempts = 0
            self.last_failed_time = None
            self.lockout_label.config(text="")
            self.build_user_dashboard()
            self.root.after(1000, self.check_session_timeout)
        else:
            self.login_attempts += 1
            if self.login_attempts >= self.max_attempts:
                self.last_failed_time = time.time()
                start_countdown()
            else:
                messagebox.showerror("Erreur", "Identifiants invalides")

    def register_window(self):
        self.clear_window()
        tk.Label(self.root, text="Créer un compte", font=("Arial", 16),fg="red").pack(pady=10)

        tk.Label(self.root, text="Nom d'utilisateur").pack()
        username_entry = tk.Entry(self.root)
        username_entry.pack()

        tk.Label(self.root, text="Mot de passe").pack()
        password_entry = tk.Entry(self.root, show='*')
        password_entry.pack()
        show_pwd = tk.BooleanVar()
        tk.Checkbutton(self.root, text="Afficher", variable=show_pwd, command=lambda: password_entry.config(show="" if show_pwd.get() else "*")).pack()


        def create_account():
         username = username_entry.get()
         password = password_entry.get()

         if not username or not password:
          messagebox.showwarning("Erreur", "Veuillez remplir tous les champs.")
          return
         if len(password) > 15:
          messagebox.showerror("Erreur", "Mot de passe trop long. Maximum 15 caractères.")
          return


         # Vérifier si le nom d'utilisateur existe déjà
         try:
          with open(ACCOUNTS_FILE, 'r') as f:
            for line in f:
                acc = json.loads(line)
                if acc['username'] == username:
                    messagebox.showerror("Erreur", "Ce nom d'utilisateur existe déjà. Veuillez en choisir un autre.")
                    return
         except FileNotFoundError:
          pass  

         salt = os.urandom(16).hex()
         hashed = hash_password(password, salt)

         with open(ACCOUNTS_FILE, 'a') as f:
          f.write(json.dumps({'username': username, 'password': hashed, 'salt': salt}) + '\n')

         messagebox.showinfo("Succès", "Compte créé. Vous pouvez maintenant vous connecter.")
         self.build_main_menu()


        tk.Button(self.root, text="Créer le compte", command=create_account).pack(pady=10)
        tk.Button(self.root, text="Retour", command=self.build_main_menu).pack(pady=5)

    def authenticate_user(self, username, password):
        try:
            with open(ACCOUNTS_FILE, 'r') as f:
                for line in f:
                    acc = json.loads(line)
                    if acc['username'] == username:
                        hashed_input = hash_password(password, acc['salt'])
                        return hashed_input == acc['password']
            return False
        except:
            return False

    def about_window(self):
        self.clear_window()
        tk.Label(self.root, text="À propos de l'application", font=("Arial", 16),fg="red").pack(pady=10)
        tk.Label(self.root, text=( 
            "Application : Gestionnaire de mots de passe sécurisé\n"
            "Développé par : Syrine Ben Ali\n"
            "Fonctionnalités :\n"
            "- Création/Connexion sécurisée avec hachage SHA-256 + sel\n"
            "- Coffre-fort AES pour les mots de passe et fichiers\n"
            "- Interface utilisateur avec Tkinter\n"
            "- Chiffrement/déchiffrement d’images\n"
        ), justify="left", font=("Arial", 11)).pack(pady=10)
        tk.Button(self.root, text="Retour au menu", command=self.build_main_menu).pack(pady=10)

    def build_user_dashboard(self):
        self.clear_window()
        tk.Label(self.root, text=f"Bienvenue {self.current_user}", font=("Arial", 16),fg="red").pack(pady=20)
        tk.Button(self.root, text="Afficher le coffre", width=30, command=self.display_vault).pack(pady=5)
        tk.Button(self.root, text="Ajouter un mot de passe", width=30, command=self.add_to_vault).pack(pady=5)
        tk.Button(self.root, text="Chiffrer un fichier", width=30, command=self.encrypt_file).pack(pady=5)
        tk.Button(self.root, text="Déchiffrer un fichier", width=30, command=self.decrypt_file).pack(pady=5)
        tk.Button(self.root, text="Déconnexion", width=30, command=self.logout).pack(pady=20)
    
    def display_vault(self):
        try:
            with open(VAULT_FILE, 'r') as f:
                data = json.load(f)
                user_data = data.get(self.current_user, {})
                decrypted = {k: decrypt_AES(v, derive_key(self.session_password)) for k, v in user_data.items()}
                messagebox.showinfo("Vos mots de passe", json.dumps(decrypted, indent=4))
        except:
            messagebox.showerror("Erreur", "Impossible de lire le coffre")
    
    def add_to_vault(self):
        service = simpledialog.askstring("Service", "Nom du service")
        pwd = simpledialog.askstring("Mot de passe", f"Mot de passe pour {service}", show='*')
        encrypted_pwd = encrypt_AES(pwd, derive_key(self.session_password))
        try:
            with open(VAULT_FILE, 'r') as f:
                data = json.load(f)
        except:
            data = {}
        if self.current_user not in data:
            data[self.current_user] = {}
        data[self.current_user][service] = encrypted_pwd
        with open(VAULT_FILE, 'w') as f:
            json.dump(data, f, indent=4)
        messagebox.showinfo("Succès", "Mot de passe enregistré")

    def encrypt_file(self):
     path = filedialog.askopenfilename()
     if not path:
        return
     with open(path, 'rb') as f:
        plaintext = f.read()
     key = derive_key(self.session_password)
     iv = get_random_bytes(16)
     cipher = AES.new(key, AES.MODE_CBC, iv)
     ciphertext = cipher.encrypt(padfile(plaintext))
    
     original_ext = os.path.splitext(path)[1]  # ex: .jpg, .txt
     out_path = path + ".enc" + original_ext   # ex: photo.jpg.enc.jpg

     with open(out_path, 'wb') as f:
        f.write(base64.b64encode(iv + ciphertext))

     messagebox.showinfo("Succès", f"Fichier chiffré : {out_path}")

    def decrypt_file(self):
     path = filedialog.askopenfilename()
     if not path:
        return
     with open(path, 'rb') as f:
        encrypted = base64.b64decode(f.read())
     iv = encrypted[:16]
     ct = encrypted[16:]
     key = derive_key(self.session_password)
     cipher = AES.new(key, AES.MODE_CBC, iv)
     try:
        plaintext = unpad(cipher.decrypt(ct))
        # Retirer .enc de ".jpg.enc.jpg" => ".jpg.jpg", puis supprimer la première extension
        base, ext = os.path.splitext(path)  # ext = .jpg
        base = base.replace(".enc", "")     # retire le ".enc"
        out_path = base + ext               # fichier restauré avec bonne extension

        with open(out_path, 'wb') as f:
            f.write(plaintext)

        messagebox.showinfo("Succès", f"Fichier déchiffré : {out_path}")
     except:
        messagebox.showerror("Erreur", "Mot de passe incorrect ou fichier corrompu")

    def logout(self):
        self.current_user = None
        self.session_password = None
        self.session_start_time = None
        self.build_main_menu()        

    def check_session_timeout(self):
     if self.session_start_time is None:
        return  

     if time.time() - self.session_start_time > 60:  # 1 minute
        messagebox.showwarning("Session expirée", "Votre session a expiré pour des raisons de sécurité.")
        self.logout()
     else:
        self.root.after(10000, self.check_session_timeout)  # vérifie toutes les 10s

   
if __name__ == "__main__":
    ensure_data_files()
    root = tk.Tk()
    root.geometry("900x500")
    app = PasswordManagerApp(root)
    root.mainloop()
